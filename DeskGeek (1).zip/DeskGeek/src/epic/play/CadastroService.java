package epic.play;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CadastroService {

    public static void cadastrarUsuario(String nome, String email, String senha) {
        try {
            DebugLoggerSwing.log("Iniciando cadastro via CadastroService");

            Connection con = Conexao.conexaoBanco();
            String sql = "INSERT INTO usuario(nome, email, senha) VALUES (?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, nome);
            stmt.setString(2, email);
            stmt.setString(3, senha);
            stmt.execute();
            stmt.close();
            con.close();

            DebugLoggerSwing.log("Usuário cadastrado com sucesso: " + nome);

        } catch (SQLException ex) {
            Logger.getLogger(CadastroService.class.getName()).log(Level.SEVERE, null, ex);
            DebugLoggerSwing.log("Erro ao cadastrar: " + ex.getMessage());
        }
    }

    public static ResultSet listarUsuarios() {
        try {
            Connection con = Conexao.conexaoBanco();
            String sql = "SELECT * FROM usuario ORDER BY id_usuario";
            PreparedStatement stmt = con.prepareStatement(sql);
            return stmt.executeQuery(); // Lembre de fechar na classe que chamar
        } catch (SQLException ex) {
            Logger.getLogger(CadastroService.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    public static void excluirUsuario(String idUsuario) {
        try {
            Connection con = Conexao.conexaoBanco();
            String sql = "DELETE FROM usuario WHERE id_usuario = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, idUsuario);
            stmt.execute();
            stmt.close();
            con.close();
            DebugLoggerSwing.log("Usuário excluído com sucesso: " + idUsuario);
        } catch (SQLException ex) {
            Logger.getLogger(CadastroService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void alterarUsuario(String idUsuario, String nome, String email, String senha) {
        try {
            Connection con = Conexao.conexaoBanco();
            String sql = "UPDATE usuario SET nome = ?, email = ?, senha = ? WHERE id_usuario = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, nome);
            stmt.setString(2, email);
            stmt.setString(3, senha);
            stmt.setString(4, idUsuario);
            stmt.executeUpdate();
            stmt.close();
            con.close();
            DebugLoggerSwing.log("Usuário alterado com sucesso: " + idUsuario);
        } catch (SQLException ex) {
            Logger.getLogger(CadastroService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
