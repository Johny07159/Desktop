package epic.play;

import org.apache.jmeter.protocol.java.sampler.AbstractJavaSamplerClient;
import org.apache.jmeter.protocol.java.sampler.JavaSamplerContext;
import org.apache.jmeter.samplers.SampleResult;

public class MeuTeste extends AbstractJavaSamplerClient {

    @Override
    public SampleResult runTest(JavaSamplerContext context) {
        SampleResult resultado = new SampleResult();
        resultado.sampleStart(); // inicia o tempo de execução

        try {
            // Chamada para a lógica de negócio da sua aplicação
            String retorno = CadastroUsuario.executarOperacao();

            resultado.sampleEnd(); // fim do tempo de execução
            resultado.setSuccessful(true);
            resultado.setResponseMessage("Teste executado com sucesso");
            resultado.setResponseData(retorno, "UTF-8");
            resultado.setDataType(SampleResult.TEXT);
        } catch (Exception e) {
            resultado.sampleEnd();
            resultado.setSuccessful(false);
            resultado.setResponseMessage("Erro: " + e.getMessage());
            resultado.setResponseData(e.toString(), "UTF-8");
        }

        return resultado;
    }
}
